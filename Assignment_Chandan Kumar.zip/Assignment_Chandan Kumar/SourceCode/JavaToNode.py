#!/usr/bin/env python3



from typing import List
from openai import OpenAI
import argparse
import os
import sys
from pathlib import Path


AI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1")

PROMPT_INSTRUCTIONS = """
You are a senior software migration engineer skilled in Java and Node.js.


Your task is to convert Java code into clean, idiomatic, runnable Node.js code.

Rules:
1. Preserve the original business logic as closely as possible.
2. Use modern JavaScript for Node.js (CommonJS unless the user asks otherwise).
3. Use async/await where appropriate.
4. Replace Java-specific constructs with idiomatic Node.js equivalents.
5. Keep important comments that explain non-obvious business logic.
6. Do not include markdown fences.
7. Do not include explanations unless explicitly requested.
8. Return only the final Node.js code.
""".strip()


TARGET_GUIDANCE = {
    "plain-node": """
Target style:
- Plain Node.js
- Avoid unnecessary frameworks
- Prefer built-in modules where practical
""".strip(),
    "express": """
Target style:
- Node.js with Express
- Convert controller/service style code into Express-friendly handlers where appropriate
- Keep routing logic practical and simple
""".strip(),
    "fastify": """
Target style:
- Node.js with Fastify
- Prefer Fastify route handlers and plugin-friendly structure where appropriate
""".strip(),
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Convert Java source code to Node.js using OpenAI."
    )
    parser.add_argument(
        "--input",
        required=True,
        help="Path to a Java file or a directory containing .java files",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Path to the output .js file or output directory",
    )
    parser.add_argument(
        "--model",
        default=AI_MODEL,
        help=f"OpenAI model name (default: {AI_MODEL})",
    )
    parser.add_argument(
        "--target",
        choices=["plain-node", "express", "fastify"],
        default="plain-node",
        help="Target Node.js style/framework",
    )
    parser.add_argument(
        "--api-key",
        default=os.getenv("OPENAI_API_KEY"),
        help="OpenAI API key. If omitted, reads OPENAI_API_KEY from environment.",
    )
    return parser.parse_args()


def strip_markdown_fences(text: str) -> str:
    cleaned = text.strip()

    if cleaned.startswith("```"):
        lines = cleaned.splitlines()
        if lines:
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        cleaned = "\n".join(lines).strip()

    return cleaned


def collect_java_files(input_path: Path) -> List[Path]:
    if input_path.is_file():
        if input_path.suffix.lower() != ".java":
            raise ValueError(f"Input file must end with .java: {input_path}")
        return [input_path]

    if input_path.is_dir():
        files = sorted(input_path.rglob("*.java"))
        if not files:
            raise ValueError(f"No .java files found in directory: {input_path}")
        return files

    raise ValueError(f"Input path does not exist: {input_path}")


def build_prompt(java_code: str, file_name: str, target: str) -> str:
    return f"""
Convert the following Java code into Node.js.

File name: {file_name}

{TARGET_GUIDANCE[target]}

Additional requirements:
- Preserve validation, condition handling, and error handling semantics.
- Keep function and variable names meaningful.
- If the Java code uses classes, convert them into practical Node.js structures.
- If imports/dependencies are needed, include them in the code.
- Return only code.

JAVA CODE:
{java_code}
""".strip()


def convert_java_to_node(
    client: OpenAI,
    java_code: str,
    file_name: str,
    model: str,
    target: str,
) -> str:
    response = client.responses.create(
        model=model,
        instructions=PROMPT_INSTRUCTIONS,
        input=build_prompt(java_code=java_code, file_name=file_name, target=target),
         temperature=0.2,
        max_tokens=5000

    )

    output = (response.output_text or "").strip()
    output = strip_markdown_fences(output)

    if not output:
        raise RuntimeError(f"Model returned empty output for {file_name}")

    return output


def convert_single_file(
    client: OpenAI,
    input_file: Path,
    output_file: Path,
    model: str,
    target: str,
) -> None:
    java_code = input_file.read_text(encoding="utf-8", errors="ignore")
    node_code = convert_java_to_node(
        client=client,
        java_code=java_code,
        file_name=input_file.name,
        model=model,
        target=target,
    )

    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(node_code, encoding="utf-8")
    print(f"[OK] {input_file} -> {output_file}")


def main() -> int:
    args = parse_args()

    if not args.api_key:
        print(
            "Error: OpenAI API key not found. Set OPENAI_API_KEY or pass --api-key.",
            file=sys.stderr,
        )
        return 1

    input_path = Path(args.input).expanduser().resolve()
    output_path = Path(args.output).expanduser().resolve()

    try:
        java_files = collect_java_files(input_path)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    client = OpenAI(api_key=args.api_key)

    try:
        if input_path.is_file():
            if output_path.exists() and output_path.is_dir():
                output_file = output_path / f"{input_path.stem}.js"
            else:
                output_file = output_path

            if output_file.suffix.lower() != ".js":
                output_file = output_file.with_suffix(".js")

            convert_single_file(
                client=client,
                input_file=input_path,
                output_file=output_file,
                model=args.model,
                target=args.target,
            )
        else:
            output_path.mkdir(parents=True, exist_ok=True)

            for java_file in java_files:
                relative = java_file.relative_to(input_path).with_suffix(".js")
                out_file = output_path / relative

                convert_single_file(
                    client=client,
                    input_file=java_file,
                    output_file=out_file,
                    model=args.model,
                    target=args.target,
                )

        print("Conversion completed successfully.")
        return 0

    except Exception as exc:
        print(f"Conversion failed: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
