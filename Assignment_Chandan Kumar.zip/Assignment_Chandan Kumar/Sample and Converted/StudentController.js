// Converted from StudentController.java
const express = require('express');
const router = express.Router();

// Simulated StudentService (replace with actual implementation)
const studentService = require('../service/StudentService');

// GET /students/:studentId/courses
router.get('/:studentId/courses', async (req, res) => {
    const { studentId } = req.params;
    try {
        const courses = await studentService.retrieveCourses(studentId);
        res.json(courses);
    } catch (err) {
        res.status(500).json({ error: 'Failed to retrieve courses' });
    }
});

// POST /students/:studentId/courses
router.post('/:studentId/courses', async (req, res) => {
    const { studentId } = req.params;
    const newCourse = req.body;

    try {
        const course = await studentService.addCourse(studentId, newCourse);

        if (!course) {
            return res.status(204).send(); // No content
        }

        // Build location URI for created resource
        const location = `${req.originalUrl}/${course.id}`;
        res.status(201).location(location).send();
    } catch (err) {
        res.status(500).json({ error: 'Failed to register course' });
    }
});

// GET /students/:studentId/courses/:courseId
router.get('/:studentId/courses/:courseId', async (req, res) => {
    const { studentId, courseId } = req.params;
    try {
        const course = await studentService.retrieveCourse(studentId, courseId);
        res.json(course);
    } catch (err) {
        res.status(500).json({ error: 'Failed to retrieve course details' });
    }
});

module.exports = router;