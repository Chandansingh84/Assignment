// Converted from StudentService.java
const crypto = require('crypto');
const { Course } = require('../model/Course');
const { Student } = require('../model/Student');

class StudentService {
    constructor() {
        this.students = [];

        // Initialize Data
        const courseOne = new Course("Course1", "Spring", "10Steps", [
            "Learn Maven", "Import Project", "First Example", "Second Example"
        ]);

        const courseTwo = new Course("Course2", "Spring MVC", "10 Examples", [
            "Learn Maven", "Import Project", "First Example", "Second Example"
        ]);

        const courseThree = new Course("Course3", "Spring Boot", "6K Students", [
            "Learn Maven", "Learn Spring", "Learn Spring MVC", "First Example", "Second Example"
        ]);

        const courseFour = new Course("Course4", "Maven", "Most popular maven course on internet!", [
            "Pom.xml", "Build Life Cycle", "Parent POM", "Importing into Eclipse"
        ]);

        const ranga = new Student("Student1", "Ranga Karanam", "Hiker, Programmer and Architect",
            [courseOne, courseTwo, courseThree, courseFour]);

        const satish = new Student("Student2", "Satish T", "Hiker, Programmer and Architect",
            [courseOne, courseTwo, courseThree, courseFour]);

        this.students.push(ranga, satish);
    }

    retrieveAllStudents() {
        return this.students;
    }

    retrieveStudent(studentId) {
        return this.students.find(student => student.id === studentId) || null;
    }

    retrieveCourses(studentId) {
        const student = this.retrieveStudent(studentId);

        if (studentId.toLowerCase() === "student1") {
            throw new Error("Something went wrong");
        }

        return student ? student.courses : null;
    }

    retrieveCourse(studentId, courseId) {
        const student = this.retrieveStudent(studentId);
        if (!student) return null;

        return student.courses.find(course => course.id === courseId) || null;
    }

    addCourse(studentId, course) {
        const student = this.retrieveStudent(studentId);
        if (!student) return null;

        const randomId = crypto.randomBytes(16).toString('hex');
        course.id = randomId;

        student.courses.push(course);
        return course;
    }
}

module.exports = new StudentService();