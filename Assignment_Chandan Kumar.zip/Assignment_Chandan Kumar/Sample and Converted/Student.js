// Converted from Student.java
class Student {
    constructor(rollNo, name) {
        this.rollNo = rollNo;
        this.name = name;
    }

    // Getters and Setters
    getRollNo() {
        return this.rollNo;
    }

    setRollNo(rollNo) {
        this.rollNo = rollNo;
    }

    getName() {
        return this.name;
    }

    setName(name) {
        this.name = name;
    }
}

module.exports = Student;